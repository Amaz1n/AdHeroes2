package com.amaz1n.adheroes2;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;

import java.awt.*;
import java.util.ArrayList;

public class AdGame extends ApplicationAdapter {
	//Stage stage;
	SpriteBatch batch;
	//Texture backG;//main background
	//Texture play1,play2,howTo1,howTo2;//main buttons
	//TextureRegionDrawable playB1,howToB1;
	//1024x800
	Texture[] slimeFrames;
	Texture[] binFrames;

	public static int SLIME,BIN,FRIES,CAT,WEIGHTS,ROBOT;
	public static int sel1,sel2;
	public static Sprite spr1;
	public static Sprite spr2;
	public static player p1;
	public static player p2;
	public static Texture stage1;
/*
	public static void main(String[] args){
		SLIME = 1; BIN = 2; FRIES = 3;
		CAT = 4; WEIGHTS = 5; ROBOT = 6;

		//selection goes here
		sel1 = SLIME;
		sel2 = SLIME;

	}
*/
	@Override
	public void create () {
		batch = new SpriteBatch();/*
		backG = new Texture("start_screen.png");
		play1 = new Texture("play_button.png");
		play2 = new Texture("play_button_hover.png");
		howTo1 = new Texture("how_to_button.png");
		howTo2 = new Texture("how_to_button_hover.png");
		playB1 = new TextureRegionDrawable(new TextureRegion(play1));
		howToB1 = new TextureRegionDrawable(new TextureRegion(howTo1));
		ImageButton playB = new ImageButton(playB1);
		ImageButton howToB = new ImageButton(howToB1);
		stage = new Stage(new ScreenViewport());
		stage.addActor(playB);
		stage.addActor(howToB);*/
		Texture s1 = new Texture("slime1_IL.png");
		Texture s2 = new Texture("slime1_IF.png");
		Texture s3 = new Texture("slime1_IR.png");
		slimeFrames = new Texture[]{s1,s2,s3};
		p1 = new player("Slime",200,4,4,slimeFrames);//make player 1
		spr1 = new Sprite(p1.getCurrentFrame());
		spr1.setPosition(p1.getX(),p1.getY());

		Texture b1 = new Texture("bin1_IL.png");
		Texture b2 = new Texture("bin1_IF.png");
		Texture b3 = new Texture("bin1_IR.png");
		binFrames = new Texture[]{b1,b2,b3};
		p2 = new player("Recycle Bin",696,8,8,binFrames);//equal distance
		spr2 = new Sprite(p2.getCurrentFrame());
		spr2.setPosition(p2.getX(),p2.getY());

		stage1 = new Texture("map_slimeFields.png");
	}

	@Override
	public void render () {

		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		/*batch.begin();
		batch.draw(backG, 0, 0);
		stage.draw();//buttons are 400x200*/
		/*if(MouseInfo.getPointerInfo().getLocation().x>=450 &&
		MouseInfo.getPointerInfo().getLocation().x<=850 &&
		MouseInfo.getPointerInfo().getLocation().y>=320 &&
		MouseInfo.getPointerInfo().getLocation().y<=520){
			batch.draw(playBH,312,320);
		}*/
		//batch.end();
		batch.begin();
		batch.draw(stage1,0,0);

		spr1.draw(batch);
		if(p1.getY()<=100){
			p1.setVY(0);
		}
		else{
			p1.setVY(-5.8f);
		}
		p1.setX(p1.getVX());
		p1.setY(p1.getVY());
		spr1.setPosition(p1.getX(),p1.getY());

		spr2.draw(batch);
		if(p2.getY()<=100){
			p2.setVY(0);
		}
		else{
			p2.setVY(-5.8f);
		}
		p2.setX(p2.getVX());
		p2.setY(p2.getVY());
		spr2.setPosition(p2.getX(),p2.getY());

		batch.end();
	}

	@Override
	public void dispose () {
		batch.dispose();
		//backG.dispose();
		//playB.dispose();
		//howToB.dispose();
	}
}

/*
slime:         FR 4, DMG 4
recycle bin:   FR 8, DMG 8
fast food man: FR12, DMG12
witch cat:     FR16, DMG16
dumbbell rack: FR20, DMG20
robot:         FR24, DMG24
*/

class player{
	private String name;
	private int x,y;//position for hit box
	private float vx,vy;//velocity
	private int hp,dmg,fireRate;
	private Texture[] frames;
	private int currentFrame;

	public player(String n,int startX,int damage,int rate,Texture[] f){
		name = n;
		x = startX; y = 800;//*******starting positions will be in the air to account for differing ground levels
		vx = 0; vy = -6.8f;//initial velocity is 0
		hp = 150;//1.5x the hp of previous game
		dmg = damage;
		fireRate = rate;
		frames = f;
		currentFrame = 1;
	}

	public String getName(){return name;}
	public int getX(){return x;}
	public int getY(){return y;}
	public float getVX(){return vx;}
	public float getVY(){return vy;}
	public int getHP(){return hp;}
	public int getDMG(){return dmg;}
	public int getRate(){return fireRate;}
	//***melee stun will be put off until core elements established
	//public void setStun(){stun = !stun;}//toggles false to true and vice versa
	public Texture getCurrentFrame(){return frames[currentFrame];}

	public void setX(float f){x+=f;}
	public void setY(float f){y+=f;}
	public void setVX(float f){vx=f;}
	public void setVY(float f){vy=f;}
}