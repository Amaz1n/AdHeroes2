package com.amaz1n.adheroes2;

import com.badlogic.gdx.graphics.Texture;

class Bullet {
    private int x,y;
    private int vx;//,vy;
    private Texture bull;

    public Bullet(Texture t){
        x=0;//initial location unimportant
        y=0;
        vx = 9;//constant speed
        bull = t;
    }
    public int getX(){return x;}
    public int getY(){return y;}
    public Texture getTexture(){return bull;}

    public void setX(int px){x = px;}
    public void setY(int py){y = py;}
}
