package com.amaz1n.adheroes2;

import com.badlogic.gdx.graphics.Texture;

class player{
    private String name;
    private int x,y;//position for hit box
    private float vx,vy;//velocity
    private int hp,dmg,fireRate;
    private Texture[][] frames;
    private int currentDirect,currentFrame;
    private boolean falling,dblJump;

    public player(String n,int startX,int damage,int rate,Texture[][] f){
        name = n;
        x = startX; y = 800;//starting positions will be in the air to account for differing ground levels
        vx = 0; vy = 0;//initial velocity is 0
        hp = 150;
        dmg = damage;
        fireRate = rate;
        frames = f;
        currentDirect = 1;//forward
        currentFrame = 0;//idle
        falling = true;
        dblJump = true;
    }

    public String getName(){return name;}
    public int getX(){return x;}
    public int getY(){return y;}
    public float getVX(){return vx;}
    public float getVY(){return vy;}
    public int getHP(){return hp;}
    public int getDMG(){return dmg;}
    public int getRate(){return fireRate;}
    //public boolean getStun(){return stun;}
    public Texture getCurrentFrame(){return frames[currentDirect][currentFrame];}
    public boolean getFalling(){return falling;}
    public boolean get2Jump(){return dblJump;}

    public void changeVY(float f){vy+=f;}//vx doesn't need this (only for gravity)
    public void changeX(float f){x+=f;}
    public void changeY(float f){y+=f;}

    public void setX(int i){x=i;}
    public void setY(int i){y=i;}
    public void setVX(float f){vx=f;}
    public void setVY(float f){vy=f;}
    public void setHP(int i){hp=i;}//DMG, fire rate don't change
    //***melee stun will be put off until core elements established
    //public void setStun(){stun = !stun;}//toggles false to true and vice versa
    public void setCurrentFrame(int d,int f){
        currentDirect = d;
        currentFrame = f;
    }
    public void setFalling(boolean b){falling=b;}
    public void set2Jump(boolean b){dblJump=b;}
}
