package com.amaz1n.adheroes2.desktop;

import com.badlogic.gdx.ApplicationAdapter;

import java.awt.*;
import java.util.ArrayList;

public class AdHeroes2 extends ApplicationAdapter {

	public static void main (String[] arg) {
		//1024x800
		
	}
}

/* ***Using 1:1 ratio for balance
slime:        FR 4, DMG 4
recycle bin:  FR 8, DMG 8
fast food man:FR12, DMG12
????:		  FR16, DMG16
????????:     FR20, DMG20
robot:        FR24, DMG24
*/

class player1{
	private String name;
	private ArrayList<Image> frames;
	private int x,y;//position for hit box
	private Rectangle hitBox;//*********might not be necessary since all hitboxes are equal?
	private int hp,dmg,fireRate;

	public player1(){//String n,int damage,int rate
		name = "Slime";//CONSTRUCTOR FIELD<<<<<<<
		//frames.add("slime1_IdleF.png");
		x = 300;//starting position for player one (constant
		y = 520;//*********************change to suit the first map (and base for other maps)
		hitBox = new Rectangle(x,y,64,64);
		hp = 150;//1.5x the hp of previous game
		dmg = 4;//CONSTRUCTOR FIELD       <<<<<<<<
		fireRate = 4;//CONSTRUCTOR FIELD  <<<<<<<<
	}

	public String getName(){return name;}
	public int getX(){return x;}
	public int getY(){return y;}
	public int getHP(){return hp;}
	public int getDMG(){return dmg;}
	public int getRate(){return fireRate;}
}
class player2{
	private String name;
	private ArrayList<Image> frames;
	private int x,y;
	private Rectangle hitBox;
	private int hp,dmg,fireRate;

	public player2(){
		name = "Ooze";//player two version (different colour)
		x = 600;//starting position for player two
		y = 520;
		hitBox = new Rectangle(x,y,64,64);
		hp = 150;
		dmg = 4;
		fireRate = 4;//same stats
	}

	public String getName(){return name;}
	public int getX(){return x;}
	public int getY(){return y;}
	public int getHP(){return hp;}
	public int getDMG(){return dmg;}
	public int getRate(){return fireRate;}
}