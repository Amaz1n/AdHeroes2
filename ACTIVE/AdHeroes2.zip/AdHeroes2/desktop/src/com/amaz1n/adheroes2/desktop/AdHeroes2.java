package com.amaz1n.adheroes2.desktop;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

import java.awt.*;

public class AdHeroes2 {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		new LwjglApplication((ApplicationListener) new AdHeroes2(), config);
		
	}
}

/////SLIME
class slime1{
	private Image slime;
	private int hp

	public Image getImage(){

	}
	public
}
class slime2{
	private Image pudding;
	private int hp

}

/////RECYCLE BIN
class bin1{

}
class bin2{

}

/////FAST FOOD MAN
class fries1{

}
class fries2{

}

/////ROBOT
class robot1{

}
class robot2{

}